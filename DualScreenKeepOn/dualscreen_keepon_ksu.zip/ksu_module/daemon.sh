#!/system/bin/sh

LOG_TAG="DualScreenKeepOn"

log() {
    echo "[$(date '+%H:%M:%S')] $1"
    log -t "$LOG_TAG" "$1"
}

log "双屏常亮守护进程启动"

# 等待系统就绪
sleep 15

while true; do
    # 检查内屏和外屏状态
    INNER_STATE=$(dumpsys display 2>/dev/null | grep -A1 "Display Id=0" | grep "Display State=" | grep -o "ON\|OFF")
    OUTER_STATE=$(dumpsys display 2>/dev/null | grep -A1 "Display Id=1" | grep "Display State=" | grep -o "ON\|OFF")
    
    if [ "$INNER_STATE" = "ON" ] && [ "$OUTER_STATE" = "OFF" ]; then
        log "检测到内屏亮但外屏灭，尝试修复..."
        
        # 方法1: 通过 device_state override 为 state 6 (双屏都亮)
        cmd device_state state 6 2>/dev/null
        log "已执行: cmd device_state state 6"
        
        # 方法2: 设置 fold_status
        echo "13 1" > /sys/devices/virtual/mi_display/disp_feature/disp-DSI-1/disp_param 2>/dev/null
        
        # 方法3: 设置背光
        echo 2047 > /sys/devices/platform/soc/ae00000.qcom,mdss_mdp/backlight/panel1-backlight/brightness 2>/dev/null
        echo 0 > /sys/devices/platform/soc/ae00000.qcom,mdss_mdp/backlight/panel1-backlight/bl_power 2>/dev/null
        
        # 方法4: 通过 app_process 调用 Java 工具
        if [ -f /data/local/tmp/DualScreenDaemon.dex ]; then
            CLASSPATH=/data/local/tmp/DualScreenDaemon.dex app_process /data/local/tmp DualScreenDaemon once 2>/dev/null
        fi
        
        log "修复完成"
    fi
    
    sleep 3
done
