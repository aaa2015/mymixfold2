#!/system/bin/sh
##########################################################
# apply_rules.sh — App Net Router 核心路由规则引擎
#
# 配置格式: pkg:wifi_flag:cell_flag (1=启用 0=禁用)
# 未在配置中的 app 默认 wifi=1 cell=0
#
# 场景:
#   wifi=0 cell=1 → 路由到蜂窝
#   wifi=1 cell=1 → 两个都可用（不做特殊处理）
#   wifi=0 cell=0 → 禁止网络 (iptables DROP)
#   wifi=1 cell=0 → 默认，不需要规则
##########################################################

MODDIR=${MODDIR:-/data/adb/modules/app_net_router}
CONF="$MODDIR/config/apps.conf"
LOGFILE="$MODDIR/logs/apply.log"
RULE_PRIO=12000
LAN_PRIO=11999
PACKAGES_LIST="/data/system/packages.list"

log() {
    local ts=$(date '+%m-%d %H:%M:%S')
    echo "[$ts] $1" >> "$LOGFILE" 2>/dev/null
    echo "[$ts] $1"
}

clean_rules() {
    log "清理旧规则..."
    while ip -4 rule del priority $LAN_PRIO 2>/dev/null; do :; done
    while ip -6 rule del priority $LAN_PRIO 2>/dev/null; do :; done
    while ip -4 rule del priority $RULE_PRIO 2>/dev/null; do :; done
    while ip -6 rule del priority $RULE_PRIO 2>/dev/null; do :; done

    # 清理 iptables
    iptables -D OUTPUT -j ANR_BLOCK 2>/dev/null
    iptables -F ANR_BLOCK 2>/dev/null
    iptables -X ANR_BLOCK 2>/dev/null
    ip6tables -D OUTPUT -j ANR_BLOCK 2>/dev/null
    ip6tables -F ANR_BLOCK 2>/dev/null
    ip6tables -X ANR_BLOCK 2>/dev/null
    log "规则已清理"
}

detect_cellular() {
    local ifaces=$(ip -6 addr show | grep -B2 'scope global' | grep 'rmnet_data' | awk -F'[ @]' '{print $2}')
    if [ -z "$ifaces" ]; then
        ifaces=$(ip link show | grep 'rmnet_data.*UP' | grep -v DOWN | awk -F'[ :@]' '{for(i=1;i<=NF;i++) if($i ~ /rmnet_data/) print $i}' | head -1)
    fi
    CELL_IF=$(echo "$ifaces" | head -1)
    [ -z "$CELL_IF" ] && return 1

    # IPv6: 找含有蜂窝接口默认路由的编号表（Android 用编号表如 1018，不是命名表）
    CELL_TABLE_V6=$(ip -6 route show table all 2>/dev/null | grep "default.*dev $CELL_IF" | head -1 | awk '{for(i=1;i<=NF;i++) if($i=="table") print $(i+1)}')
    # IPv4: 同样查找
    CELL_TABLE_V4=$(ip -4 route show table all 2>/dev/null | grep "default.*dev $CELL_IF" | head -1 | awk '{for(i=1;i<=NF;i++) if($i=="table") print $(i+1)}')
    # IPv4 回退: 任意 rmnet_data 接口
    if [ -z "$CELL_TABLE_V4" ]; then
        CELL_TABLE_V4=$(ip -4 route show table all 2>/dev/null | grep "default.*dev rmnet_data" | head -1 | awk '{for(i=1;i<=NF;i++) if($i=="table") print $(i+1)}')
    fi

    log "蜂窝接口: $CELL_IF | IPv6表: ${CELL_TABLE_V6:-无} | IPv4表: ${CELL_TABLE_V4:-无}"
    return 0
}

get_uid() {
    local pkg=$1
    local uid=""
    if [ -f "$PACKAGES_LIST" ]; then
        uid=$(grep "^$pkg " "$PACKAGES_LIST" | awk '{print $2}')
    fi
    if [ -z "$uid" ]; then
        uid=$(pm list packages -U 2>/dev/null | grep "$pkg" | sed 's/.*uid://')
    fi
    echo "$uid"
}

apply_rules() {
    if [ ! -f "$CONF" ]; then
        log "配置文件不存在: $CONF"
        return 1
    fi

    detect_cellular
    local has_cell=$?

    local wifi_up=$(ip link show wlan0 2>/dev/null | grep -c 'UP')

    clean_rules

    # rp_filter 松散模式
    if [ "$has_cell" -eq 0 ] && [ -n "$CELL_IF" ]; then
        [ -f /proc/sys/net/ipv4/conf/$CELL_IF/rp_filter ] && echo 2 > /proc/sys/net/ipv4/conf/$CELL_IF/rp_filter
        [ -f /proc/sys/net/ipv4/conf/wlan0/rp_filter ] && echo 2 > /proc/sys/net/ipv4/conf/wlan0/rp_filter
        [ -f /proc/sys/net/ipv4/conf/all/rp_filter ] && echo 2 > /proc/sys/net/ipv4/conf/all/rp_filter
    fi

    # 创建 iptables 链（用于禁网场景）
    iptables -N ANR_BLOCK 2>/dev/null
    ip6tables -N ANR_BLOCK 2>/dev/null

    local count_cell=0
    local count_block=0

    while IFS= read -r line || [ -n "$line" ]; do
        line=$(echo "$line" | sed 's/#.*//' | tr -d '[:space:]')
        [ -z "$line" ] && continue

        # 解析 pkg:wifi:cell 格式
        local pkg=$(echo "$line" | cut -d: -f1)
        local wifi_flag=$(echo "$line" | cut -d: -f2)
        local cell_flag=$(echo "$line" | cut -d: -f3)

        [ -z "$pkg" ] && continue

        # 兼容旧格式（只有包名，无冒号）
        if [ -z "$wifi_flag" ]; then
            wifi_flag=0
            cell_flag=1
        fi

        local uid=$(get_uid "$pkg")
        if [ -z "$uid" ]; then
            log "⚠ 未找到包: $pkg"
            continue
        fi

        # wifi=1 cell=0 → 默认，不需要规则
        if [ "$wifi_flag" = "1" ] && [ "$cell_flag" = "0" ]; then
            continue
        fi

        # wifi=0 cell=1 → 走蜂窝（局域网仍走 WiFi）
        if [ "$wifi_flag" = "0" ] && [ "$cell_flag" = "1" ]; then
            if [ "$has_cell" -eq 0 ]; then
                # 局域网例外: 优先级更高(11999)，局域网流量走 main 表(WiFi)
                ip -4 rule add uidrange "$uid-$uid" to 192.168.0.0/16 table main priority $LAN_PRIO
                ip -4 rule add uidrange "$uid-$uid" to 10.0.0.0/8 table main priority $LAN_PRIO
                ip -4 rule add uidrange "$uid-$uid" to 172.16.0.0/12 table main priority $LAN_PRIO
                ip -6 rule add uidrange "$uid-$uid" to fe80::/10 table main priority $LAN_PRIO
                # 公网流量走蜂窝
                if [ -n "$CELL_TABLE_V6" ]; then
                    ip -6 rule add uidrange "$uid-$uid" table "$CELL_TABLE_V6" priority $RULE_PRIO
                fi
                if [ -n "$CELL_TABLE_V4" ]; then
                    ip -4 rule add uidrange "$uid-$uid" table "$CELL_TABLE_V4" priority $RULE_PRIO
                fi
                log "✓ $pkg (UID $uid) → 蜂窝(公网) + WiFi(局域网)"
                count_cell=$((count_cell + 1))
            else
                log "⚠ $pkg 需要蜂窝但蜂窝未连接"
            fi
            continue
        fi

        # wifi=1 cell=1 → 两个都启用，不需要特殊规则
        if [ "$wifi_flag" = "1" ] && [ "$cell_flag" = "1" ]; then
            log "✓ $pkg (UID $uid) → WiFi+蜂窝"
            continue
        fi

        # wifi=0 cell=0 → 禁止网络
        if [ "$wifi_flag" = "0" ] && [ "$cell_flag" = "0" ]; then
            iptables -A ANR_BLOCK -m owner --uid-owner "$uid" -j DROP 2>/dev/null
            ip6tables -A ANR_BLOCK -m owner --uid-owner "$uid" -j DROP 2>/dev/null
            log "✗ $pkg (UID $uid) → 禁止网络"
            count_block=$((count_block + 1))
            continue
        fi
    done < "$CONF"

    # 激活 iptables 链
    if [ $count_block -gt 0 ]; then
        iptables -I OUTPUT -j ANR_BLOCK
        ip6tables -I OUTPUT -j ANR_BLOCK
    fi

    log "完成: ${count_cell} 个走蜂窝, ${count_block} 个禁网"

    echo "$CELL_TABLE_V6" > "$MODDIR/logs/.cell_table_v6" 2>/dev/null
    echo "$CELL_TABLE_V4" > "$MODDIR/logs/.cell_table_v4" 2>/dev/null
    echo "$CELL_IF" > "$MODDIR/logs/.cell_if" 2>/dev/null

    return 0
}

mkdir -p "$MODDIR/logs"

case "$1" in
    --clean) clean_rules ;;
    *) apply_rules ;;
esac
